<div class="top_part_menu">
             <h3>Accounce Transection</h3>
             <ul>
                <li><a href="../index.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Home</a></li> 
                <li><a href="../transection/transection_pannel.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Student Transaction</a></li> 
                <li><a href="../bank/bank_pannel.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Bank Transaction</a></li> 
                <li><a href="../expence/expence_pannel.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Expence</a></li>                 
                <li><a href="../other_income/other_income_pannel.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Other Income</a></li>                  
             </ul>   
            <h3>Accounce Report</h3>
            <ul>
          
                <li><a href="collection_report.php"><i class="fa fa-picture-o" aria-hidden="true"></i>Collection Report of Student</a></li>
                <li><a href="other_income_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Other Income Report</a></li>
                <li><a href="total_income_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Total Income Report</a></li>
                <li><a href="expence_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Expence Report</a></li>
                <li><a href="income_expence_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Income Expence Report</a></li>
                <li><a href="bank_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Bank Report</a></li>                
                <li><a href="payment_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Payment History</a></li>           
                <li><a href="due_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Due History</a></li>                 
                           </ul>
            
             
            
        </div>