
<?php
require_once('fees_sett_top.php');
 
 require_once '../../../lib/htmlpurifier/library/HTMLPurifier.auto.php';
    
    $purifier = new HTMLPurifier();
    //$clean_html = $purifier->purify($dirty_html);
	
	if (!function_exists('clean_html')) {
		function clean_html($dirty_html = ''){
			if(empty($dirty_html))
			return $dirty_html;		
				
			global $purifier;
			$clean_html = $purifier->purify($dirty_html);
			return $clean_html;
		}
		
	}
	
							

		
		
		$studClass = $_POST['studClass'];
		$fiscalid=$_POST['fiscalid'];
        $headname=$_POST['headname'];
        $amount=$_POST['amount'];
        $civilian_amount=$_POST['civilian_amount'];
        $stsess = $_POST['stsess'];
        $type = $_POST['type'];
        if(empty($_POST['month'])){
           $month = 0; 
        }
        else{
        $month = $_POST['month'];
        }
        
	
	
// 	echo  $studClass;
// 	echo  $fiscalid;
// 	echo  $headname;
// 	echo  $amount;
// 	echo  $stsess;
// 	echo  $type;

		
		$getFeesHeadName="select * from fees_head WHERE class_id = '$studClass' AND fiscal_year_id = '$fiscalid' AND head_name = '$headname'";
 	$qgetFeesHeadName=$mysqli->query($getFeesHeadName);
	$shFeesHeadName=$qgetFeesHeadName->fetch_assoc();
	
	$gheadname=$shFeesHeadName['head_name'];

	
	

	
		
	if($gheadname==$headname) { 
	    
	   // echo "tes1";
	  //  header('Location: fiscal_year_setup.php?msg=3');  
	
	$message = 'Fees Head Already Exist.';

    echo "<SCRIPT> 
        alert('$message')
        window.location.replace('fees_head_setup.php');
    </SCRIPT>";
	    
	}
	
	
	else {
	
//	echo "test3";
	
	$infeeshead="INSERT INTO `fees_head`(`class_id`, `fiscal_year_id`, `stsess`, `head_name`, `amount`,`civilian_students_amount`, `head_type`,`month_id`) 
	                             VALUES ('$studClass','$fiscalid','$stsess','$headname','$amount','$civilian_amount','$type','$month')";
	        						$qinfeeshead=$mysqli->query($infeeshead);
						
     						if($qinfeeshead)  { 
	        						   // header('location:fiscal_year_setup.php?msg=1');
	        						   	$message = 'Success.';
                                            echo "<SCRIPT> 
                                                alert('$message')
                                                window.location.replace('fees_head_setup.php');
                                            </SCRIPT>";

                             } 
                             else {
                                 
                                // header('location:fiscal_year_setup.php?msg=2');
                                 	  $message = 'Failed.';
                                            echo "<SCRIPT> 
                                                alert('$message')
                                                window.location.replace('fees_head_setup.php');
                                            </SCRIPT>";
                             }
     	}
		
		
			
 ?>