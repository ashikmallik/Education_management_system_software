<div class="top_part_menu">
            <h3>Setup</h3>
            
            <ul>
                <li><a href="../index.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Home</a></li> 
                <li><a href="fiscal_year_setup.php"><i class="fa fa-picture-o" aria-hidden="true"></i>Fiscal Year Setup</a></li>
                <li><a href="fees_head_setup.php"><i class="fa fa-picture-o" aria-hidden="true"></i>Fees Head Setup</a></li>
                <li><a href="fees_head_list.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Fees Head List</a></li>
                <li><a href="process_setup.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Process Setup</a></li>
                
                <li><a href="process.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Process</a></li> 
                
         <li><a href="student_due_list.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Due List</a></li>     
            
        <li><a href="fees_collection.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Fees Collection</a></li>
                
     <li><a href="increase_fees.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Fees & Balance Increase Fees</a></li>
     
            <li><a href="decrease_fees.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Fees & Balance Decrease Fees</a></li> 
        
               
               <li><a href="fees_report.php"><i class="fa fa-info-circle" aria-hidden="true"></i>Fees Report</a></li>                
                           </ul>
            
             
            
        </div>