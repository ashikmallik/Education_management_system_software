<div class="side-nav-inner">
                    <ul class="side-nav-menu scrollable">
                        <li class="nav-item dropdown open inneractive">
                            <a class="dropdown-toggle" href="https://amareskul.com/mmsc/pannel/academic/">
                                <span class="icon-holder">
                                    <img src="assets/images/fessicon/icon_dashboard.svg" alt="">
                                </span>
                                <span class="title">Home</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                        </li>

                           
                        </li>
                        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="supportDashboard.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Dashboard</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                           
                        </li>
                        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="total_solved.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Solved Ticket</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                           
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="total_request.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Total Requesting Ticket</span>
                                <!-- <span class="arrow">
									<i class="arrow-icon"></i>
								</span> -->
                            </a>
                            
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="total_pending.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Pending Ticket</span>
                            </a>
                            
                        </li>
                        
                    </ul>
                </div>