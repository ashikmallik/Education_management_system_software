<?php
$server = 'localhost';
$user = 'bornosky_u_kbboc';
$pass = 'Bangladesh`1234';
$db_name = 'bornosky_kbboc';
$mysqli = mysqli_connect($server, $user, $pass, $db_name);

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
?>
