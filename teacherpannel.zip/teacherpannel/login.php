<div class="login_btn">
    <div class="login_menu">
        <a href="create.php">
            <img src="images/create_logo.jpg" height="60px" width="80px">
            <p>Create Account</p>
        </a>
    </div>

    <div class="login_menu">
        <a href="borno_login.php">
            <img src="images/login_logo.jpg" height="60px" width="80px">
            <p>Login</p>
        </a>
    </div>
</div>